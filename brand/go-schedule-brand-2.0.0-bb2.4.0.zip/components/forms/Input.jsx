export function Input({ id, label, required = false, error, ...props }) {
  return (
    <div className="go-field">
      <label className="go-field__label" htmlFor={id}>{label}{required ? <span className="go-field__required" aria-hidden="true"> *</span> : null}</label>
      <input className="go-field__control" id={id} required={required} {...props} type="text" />
      {error ? <p className="go-field__error" role="alert">{error}</p> : null}
    </div>
  );
}
