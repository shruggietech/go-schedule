export function Select({ id, label, required = false, error, children, ...props }) {
  return (
    <div className="go-field">
      <label className="go-field__label" htmlFor={id}>{label}{required ? <span className="go-field__required" aria-hidden="true"> *</span> : null}</label>
      <select className="go-field__control" id={id} required={required} {...props}>{children}</select>
      {error ? <p className="go-field__error" role="alert">{error}</p> : null}
    </div>
  );
}
