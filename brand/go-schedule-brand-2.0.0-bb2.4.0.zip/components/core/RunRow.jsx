export function RunRow({ scheduled_at, started_at, duration, exit_state }) {
  return <div className="go-run-row" role="row"><div className="go-run-row__scheduled_at" role="cell">{scheduled_at}</div><div className="go-run-row__started_at" role="cell">{started_at}</div><div className="go-run-row__duration" role="cell">{duration}</div><div className="go-run-row__exit_state" role="cell">{exit_state}</div></div>;
}
