export function Divider() {
  return <hr className="go-divider" />;
}
