export function Card({ children, ...props }) {
  return <div className="go-card" {...props}>{children}</div>;
}
