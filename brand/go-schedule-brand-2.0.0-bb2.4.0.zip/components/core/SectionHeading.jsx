export function SectionHeading({ eyebrow, title, description }) {
  return <header className="go-section-heading">{eyebrow ? <div className="go-eyebrow">{eyebrow}</div> : null}<h2 className="go-section-heading__title">{title}</h2>{description ? <p className="go-section-heading__description">{description}</p> : null}</header>;
}
