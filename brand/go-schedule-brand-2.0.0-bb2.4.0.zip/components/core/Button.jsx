export function Button({ variant = "primary", size = "md", children, ...props }) {
  return <button className={`go-button go-button--${variant} go-button--${size}`} type="button" {...props}>{children}</button>;
}
