export function PolicyRow({ timezone, catch_up, overlap, service }) {
  return <div className="go-policy-row" role="row"><div className="go-policy-row__timezone" role="cell">{timezone}</div><div className="go-policy-row__catch_up" role="cell">{catch_up}</div><div className="go-policy-row__overlap" role="cell">{overlap}</div><div className="go-policy-row__service" role="cell">{service}</div></div>;
}
