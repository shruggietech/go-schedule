export function Badge({ tone = "neutral", children }) {
  return <span className={`go-badge go-badge--${tone}`}>{children}</span>;
}
