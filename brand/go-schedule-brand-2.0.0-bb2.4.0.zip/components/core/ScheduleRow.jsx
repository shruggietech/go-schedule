export function ScheduleRow({ expression, timezone, next_run, catch_up, overlap, state }) {
  return <div className="go-schedule-row" role="row"><div className="go-schedule-row__expression" role="cell">{expression}</div><div className="go-schedule-row__timezone" role="cell">{timezone}</div><div className="go-schedule-row__next_run" role="cell">{next_run}</div><div className="go-schedule-row__catch_up" role="cell">{catch_up}</div><div className="go-schedule-row__overlap" role="cell">{overlap}</div><div className="go-schedule-row__state" role="cell">{state}</div></div>;
}
