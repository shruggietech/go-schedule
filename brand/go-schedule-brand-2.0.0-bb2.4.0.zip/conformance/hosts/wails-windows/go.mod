module brandbuilder/go-schedule/wails_conformance

go 1.22
