# Implementation Contract: go-schedule

Generated from `enforcement/documentation-facts.json` under documentation contract `1.0.0`. This file describes the exact delivered kit and remains authoritative offline.

## Exact versions

| Domain | Version |
| --- | --- |
| Brand Canon | `1.6.0` |
| Interface Canon | `1.0.1` |
| Component recipes | `1.1.0` |
| Web/React adapter | `1.1.0` |
| egui adapter | `1.0.2` |
| BrandBuilder | `2.4.0` |
| Brand | `2.0.0` |

Package identity: `go-schedule-brand-2.0.0-bb2.4.0` (`go-schedule-brand-2.0.0-bb2.4.0.zip`)

## Bindings

- **Interface Canon:** `enforcement/interface-canon.json`
- **Component Recipes:** `enforcement/component-recipes.json`
- **Web Adapter:** `web/adapter.json`
- **Web Support Matrix:** `web/support-matrix.json`
- **Egui Adapter:** `native/egui/adapter.json`
- **Egui Support Matrix:** `native/egui/support-matrix.json`

## Inheritance and overrides

Inheritance mode: `shruggietech-house`.

Declared interface overrides:
- None.

Follow authority in this order: `brand.json` -> `enforcement/bundle.json` -> `enforcement/release-impact.json` -> `enforcement/interface-canon.json` -> `enforcement/component-recipes.json` -> `enforcement/version-policy.json` -> `enforcement/documentation-contract.json` -> `enforcement/consumer-contract.json` -> `human instructions that do not conflict`.

## Verification

- `python3 enforcement/brandbuilder/templates/verify.py .`
- `python3 enforcement/brandbuilder/templates/validate_glyph.py brand.json`

Success means zero verifier problems and zero glyph failures.

## Offline recovery

Verify `e6603222d1aa3987d515a82094862b78632acfd89e4f71d711b9a6ca1041930c` for `enforcement/distributions/shruggie-brandbuilder-2.4.0.skill`, then extract it to `enforcement/brandbuilder`. Use the delivered bundle and never substitute an unspecified latest release.

Capability gaps stay local at `enforcement/capability-gap.example.json` until a human explicitly authorizes upstream submission.

## Migration impact

This release includes an approved identity redesign. Brand version `2.0.0` remains distinct from package `go-schedule-brand-2.0.0-bb2.4.0`.

| Surface | Classification | Guidance |
| --- | --- | --- |
| Identity | required | Go Schedule 2.0.0 promotes the existing reduced prompt and cursor paths to the current primary mark. Other approved mark geometry remains unchanged. |
| Palette | unaffected | Existing approved formal and interface colors remain unchanged. |
| Typography | unaffected | Existing local fonts and outlined wordmarks remain authoritative. |
| Platform Assets | required | Go Schedule marks, paired lockups, icons, and previews use the simplified primary mark. Every brand gains a distinct approved social image and legacy direct-link aliases. |
| Web React | unaffected | The Web and React adapter API and token roles remain unchanged. |
| Egui | unaffected | The egui adapter API and approved values remain unchanged. |
| Documentation | required | Brand guides and the hosted site distinguish social images from logo lockups. Brand landing metadata uses exact verified kit image bytes. |
| Recovery | required | Regenerate and repin affected kits with exact 2.4.0 package checksums. Go Schedule 2.0.0 is an identity migration; other brands gain social assets under their minor versions. |

`required` applies to existing use of that surface, `optional` is an available capability, and `unaffected` requires no migration.

For shared architecture and extension guidance, read [/docs/](https://brand.shruggie.tech/docs/). The hosted reference describes only the current generated kit. This bundled contract continues to govern these pinned delivered bytes.

## Brand-specific governed rules

# Agent Contract: go-schedule

**Read this before writing any UI. It takes a minute and it is binding.**

You are working inside a brand with a fixed vocabulary. If you need a value
that is not in this document, **stop and ask**. Do not invent one, and do not
reach for a stock Tailwind palette class because it is faster.

## The stop condition

Inventing a colour, a spacing value, a radius, a font, or a component prop is
the failure this contract exists to prevent. When the vocabulary below does not
cover what you need, say so and wait.

## Colour: use the slot, never the value

Write `bg-primary`, `text-muted-foreground`, `border-border`. Never write a
hex, an `rgb()`, or `bg-slate-900`.

| Slot | Dark | Light |
| --- | --- | --- |
| `background` | `#071014` | `#F8F8F6` |
| `foreground` | `#FFFFFF` | `#0A0A0A` |
| `card` | `#0D171C` | `#FFFFFF` |
| `primary` | `#58A6FF` | `#1160C6` |
| `muted-foreground` | `#9A9A9A` | `#6B6B6B` |
| `destructive` | `#E9505F` | `#C0293A` |
| `border` / `input` | `#262626` | `#E5E5E5` |

### Three colour mistakes that get made constantly

1. **White text on the accent.** `#FFFFFF` on `#58A6FF` measures 2.53:1 and
   fails. The legal foreground is `#000000` at 8.31:1. Use
   `text-primary-foreground` and it is handled.
2. **The bright accent as text on a light surface.** `#58A6FF` measures 2.38:1
   on `#F8F8F6`. The light block already substitutes `#1160C6`. Never override it.
3. **`#C24000` as text.** It measures 4.03:1 on the dark base. It is a fill.
   Its legal foreground is `#FFFFFF` at 5.21:1.

## Spacing and radius

Spacing scale, in px: 4/8/12/16/24/32/48/64/96/120. Nothing between them.

Radii: `rounded-sm` 6 (chips), `rounded-md` 8 (buttons, inputs, popovers),
`rounded-xl` 12 (cards, dialogs), `rounded-2xl` 16, `rounded-full` (badges).
Never `rounded-none`, never an arbitrary `rounded-[...]`.

Layout: content 1200px, narrow 720px. Gutters 24px then 48px then 80px. Section rhythm 120px then 160px then 200px.

## Type

Space Grotesk for display at 500/700. Geist for body at 400/500. Geist Mono for labels,
code, and metadata at 400.

Asking for an undeclared weight makes the renderer synthesise or substitute a face, which prints badly and forces outlined glyphs into PDFs. In mono, carry emphasis with colour.

## Affiliation

This is a ShruggieTech-owned child brand. The only approved ownership endorsement is `A ShruggieTech project`. Keep it outside the logo clear space.



## Density

Two settings ship, and both are correct in the right place. Default for
marketing and reading surfaces; compact for dense tabular data. Do not invent
a third.

## Components and AppFrame

Read `component-recipes.json` and `../web/adapter.json` before composing shared controls. Use `../tokens/interface.css` for semantic custom properties without React. React consumers import static components from `../web/react/server.tsx` and behavior-heavy controls from `../web/react/client.tsx` with exact `radix-ui@1.6.7`.

`AppFrame` is the application shell owner. It owns safe areas, dynamic viewport behavior, root scrolling, fixed chrome, IME obstruction, titlebar avoidance, and global focus unless the selected browser, Tauri, or Wails profile transfers that one responsibility to the host. Never apply the same inset in native and web layers. Product screens, navigation trees, raw style props, and open-ended element substitution are outside the recipe grammar.

## Icons

lucide, inline SVG, `currentColor`, 1.5 to 2px stroke on a 24 grid. Do not
install another icon library. If lucide lacks a domain symbol, it goes in
`icons/` drawn to the same spec.

## Accessibility, non-negotiable

- Visible 2px focus ring at 2px offset on every interactive element
- Status never carried by colour alone; pair it with a label or a shape
- Respect `prefers-reduced-motion`
- WCAG AA at rendered size

## Copy

go-schedule copy is exact, operational, calm, competent and fair to cron. Put the current schedule state and the governing timezone and policy first. Use familiar nouns and verbs. Keep
sentences short.

Headlines name something a reader can act on. Prefer literal product
language such as "Schedules as fields and run points." to slogans, mood, or abstract benefit claims.

Do not reach for: vague claims; hidden policy; hype or urgency; condescending tutorials; jokes at cron's expense.

Night, Panel, and Line provide the infrastructure surface. Anchor Blue carries identity, links, focus, and exact run points. Interval Mint carries recurrence and success. Hold Amber and Stop Red remain scarce operational signals.


Never build a sentence out of `X, not Y`, or `X over Y`, or
`rather than merely Z`. It is the clearest tell of machine-written copy.
Avoid em-dashes; use parentheses, commas, or hyphens. No testimonials, no
feature grids standing in for an explanation, no manufactured urgency.

## Before you call it done

```bash
npx eslint --config enforcement/eslint.brand.mjs .
npx stylelint --config enforcement/stylelint.config.json "**/*.css"
python3 enforcement/brandbuilder/templates/verify.py .
python3 enforcement/brandbuilder/templates/validate_glyph.py brand.json
```

A build that fails any of these is not finished, whatever it looks like.
