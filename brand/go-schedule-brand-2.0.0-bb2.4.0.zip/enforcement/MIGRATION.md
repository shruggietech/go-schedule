## Migration impact

This release includes an approved identity redesign. Brand version `2.0.0` remains distinct from package `go-schedule-brand-2.0.0-bb2.4.0`.

| Surface | Classification | Guidance |
| --- | --- | --- |
| Identity | required | Go Schedule 2.0.0 promotes the existing reduced prompt and cursor paths to the current primary mark. Other approved mark geometry remains unchanged. |
| Palette | unaffected | Existing approved formal and interface colors remain unchanged. |
| Typography | unaffected | Existing local fonts and outlined wordmarks remain authoritative. |
| Platform Assets | required | Go Schedule marks, paired lockups, icons, and previews use the simplified primary mark. Every brand gains a distinct approved social image and legacy direct-link aliases. |
| Web React | unaffected | The Web and React adapter API and token roles remain unchanged. |
| Egui | unaffected | The egui adapter API and approved values remain unchanged. |
| Documentation | required | Brand guides and the hosted site distinguish social images from logo lockups. Brand landing metadata uses exact verified kit image bytes. |
| Recovery | required | Regenerate and repin affected kits with exact 2.4.0 package checksums. Go Schedule 2.0.0 is an identity migration; other brands gain social assets under their minor versions. |

`required` applies to existing use of that surface, `optional` is an available capability, and `unaffected` requires no migration.
