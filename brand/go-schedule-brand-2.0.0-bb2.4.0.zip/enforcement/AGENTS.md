<!-- BEGIN SHRUGGIE-BRANDBUILDER: CONSUMER CONTRACT -->

## Governed BrandBuilder contract

BrandBuilder is mandatory for brand-system authoring, consumer implementation, and conformance audit. This kit pins Brand Canon `1.6.0`, Interface Canon `1.0.1`, component recipes `1.1.0`, Web/React adapter `1.1.0`, egui adapter `1.0.2`, compiler `2.4.0`, and brand `2.0.0`.

Read `consumer-contract.json`, then `IMPLEMENTATION.md`. The pinned contract outranks screenshots, legacy stylesheets, and inferred local values. Do not reinterpret identity or create a permanent parallel design system.

Affiliation boundary: this is a ShruggieTech-owned child brand with declared parent `ShruggieTech`.

If BrandBuilder `2.4.0` is absent, verify SHA-256 `e6603222d1aa3987d515a82094862b78632acfd89e4f71d711b9a6ca1041930c` and extract `enforcement/distributions/shruggie-brandbuilder-2.4.0.skill` into the empty directory `enforcement/brandbuilder`. Never substitute another version. Run `python3 enforcement/brandbuilder/templates/verify.py .` and `python3 enforcement/brandbuilder/templates/validate_glyph.py brand.json`; both must report zero failures.
<!-- END SHRUGGIE-BRANDBUILDER: CONSUMER CONTRACT -->
